# MiniBank Practice Project

A Java console banking program using account types, a service layer, file storage and transaction logs. This is a separate implementation for practicing the OOPJ MiniBank topics.

## Build

Requires JDK 17 or later. In PowerShell, run:

```powershell
.\build.ps1
java -jar .\minibank.jar
```

If Maven is installed, run the JUnit checks with `mvn test`.

## Menu

- Open a savings, current or term-deposit account
- Deposit, withdraw or transfer
- View a statement or list accounts
- Process a batch of deposit, withdrawal and transfer commands
- Read the daily transaction summary
- Enter `0` to save and exit

Account files and logs are created in a `data` folder beside the program. Savings accounts keep a minimum balance of ₹1,000; current accounts have a ₹10,000 overdraft limit; term deposits do not allow withdrawals in this version.
