package bank;

import bank.error.BankException;
import bank.model.Account;
import bank.service.BankService;
import bank.service.BatchProcessor;
import bank.util.Command;
import bank.util.CommandType;
import bank.util.InputValidator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private enum Option { OPEN, DEPOSIT, WITHDRAW, TRANSFER, STATEMENT, LIST, BATCH, REPORT, EXIT }

    public static void main(String[] args) {
        BankService bank = new BankService();
        System.out.println("Welcome to MiniBank - Riverside Branch");

        try (Scanner in = new Scanner(System.in)) {
            boolean active = true;
            while (active) {
                showMenu();
                String answer = in.nextLine().trim();
                if (answer.equals("0")) {
                    active = false;
                    continue;
                }

                Option option = switch (answer) {
                    case "1" -> Option.OPEN;
                    case "2" -> Option.DEPOSIT;
                    case "3" -> Option.WITHDRAW;
                    case "4" -> Option.TRANSFER;
                    case "5" -> Option.STATEMENT;
                    case "6" -> Option.LIST;
                    case "7" -> Option.BATCH;
                    case "8" -> Option.REPORT;
                    default -> null;
                };
                if (option == null) {
                    System.out.println("Choose 1-8, or 0 to exit.");
                    continue;
                }
                try {
                    switch (option) {
                        case OPEN -> open(in, bank);
                        case DEPOSIT -> { bank.deposit(accountNo(in), amount(in)); System.out.println("Deposit recorded."); }
                        case WITHDRAW -> { bank.withdraw(accountNo(in), amount(in)); System.out.println("Withdrawal recorded."); }
                        case TRANSFER -> {
                            String from = accountNo(in);
                            System.out.print("To account number: ");
                            String to = in.nextLine().trim();
                            bank.transfer(from, to, amount(in));
                            System.out.println("Transfer recorded.");
                        }
                        case STATEMENT -> System.out.println(bank.statement(accountNo(in)));
                        case LIST -> bank.list().forEach(System.out::println);
                        case BATCH -> runBatch(in, bank);
                        case REPORT -> System.out.println(bank.report());
                        case EXIT -> active = false;
                    }
                } catch (BankException | IllegalArgumentException e) {
                    System.out.println("Could not complete that request: " + e.getMessage());
                } catch (IOException e) {
                    System.out.println("File error: " + e.getMessage());
                }
            }
        }
        try {
            bank.save();
            System.out.println("Accounts saved. Goodbye.");
        } catch (IOException e) {
            System.out.println("Unable to save accounts: " + e.getMessage());
        }
    }

    private static void open(Scanner in, BankService bank) throws BankException {
        System.out.print("Owner name: ");
        String owner = in.nextLine().trim();
        System.out.print("Account type (SAVINGS/CURRENT/TERM): ");
        String type = in.nextLine().trim();
        System.out.print("Opening balance in rupees: ");
        long opening = Long.parseLong(in.nextLine().trim());
        Account account = bank.openAccount(owner, opening, type);
        System.out.println("Created " + account);
    }

    private static String accountNo(Scanner in) {
        System.out.print("Account number: ");
        return in.nextLine().trim();
    }

    private static long amount(Scanner in) {
        System.out.print("Amount in rupees: ");
        String value = in.nextLine().trim();
        if (!InputValidator.isPositiveAmount(value)) throw new IllegalArgumentException("Enter a positive whole number.");
        return Long.parseLong(value);
    }

    private static void runBatch(Scanner in, BankService bank) {
        System.out.println("Enter DEPOSIT account amount, WITHDRAW account amount, or TRANSFER from to amount.");
        System.out.println("Press Enter on an empty line when finished.");
        List<Command> commands = new ArrayList<>();
        while (true) {
            String line = in.nextLine().trim();
            if (line.isEmpty()) break;
            try { commands.add(Command.parse(line)); }
            catch (RuntimeException e) { System.out.println("Skipped line: " + e.getMessage()); }
        }
        for (String result : new BatchProcessor(bank).process(commands)) System.out.println(result);
    }

    private static void showMenu() {
        System.out.println("\n1 Open account   2 Deposit   3 Withdraw   4 Transfer");
        System.out.println("5 Statement      6 List      7 Batch      8 Daily report   0 Exit");
        System.out.print("Choice: ");
    }
}
