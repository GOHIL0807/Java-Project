package bank.util;
public record Command(CommandType type, String source, String destination, long amount) {
    public static Command parse(String line) {
        String[] part=line.trim().split("\\s+");
        if (part.length==3) {
            CommandType type=CommandType.valueOf(part[0].toUpperCase());
            if (type==CommandType.TRANSFER) throw new IllegalArgumentException("Transfer needs source, destination and amount.");
            if (!InputValidator.isPositiveAmount(part[2])) throw new IllegalArgumentException("Amount must be positive.");
            return new Command(type,part[1],null,Long.parseLong(part[2]));
        }
        if (part.length==4 && part[0].equalsIgnoreCase("TRANSFER")) {
            if (!InputValidator.isPositiveAmount(part[3])) throw new IllegalArgumentException("Amount must be positive.");
            return new Command(CommandType.TRANSFER,part[1],part[2],Long.parseLong(part[3]));
        }
        throw new IllegalArgumentException("Use TYPE ACCOUNT AMOUNT or TRANSFER FROM TO AMOUNT.");
    }
}
