package bank.util;

import bank.model.annotation.MaxLength;
import bank.model.annotation.Positive;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public final class AnnotationValidator {
    private AnnotationValidator() {}
    public static String[] validate(Object value) {
        List<String> errors=new ArrayList<>();
        for(Class<?> type=value.getClass();type!=null&&type!=Object.class;type=type.getSuperclass()) {
            for(Field field:type.getDeclaredFields()) {
                try {
                    field.setAccessible(true);
                    Object item=field.get(value);
                    if(field.isAnnotationPresent(Positive.class)&&item instanceof Number n&&n.longValue()<=0)
                        errors.add(field.getName()+": "+field.getAnnotation(Positive.class).message());
                    if(field.isAnnotationPresent(MaxLength.class)&&item instanceof String s&&s.length()>field.getAnnotation(MaxLength.class).value())
                        errors.add(field.getName()+": maximum length is "+field.getAnnotation(MaxLength.class).value());
                } catch(IllegalAccessException e) { errors.add(field.getName()+": could not inspect field"); }
            }
        }
        return errors.toArray(String[]::new);
    }
}
