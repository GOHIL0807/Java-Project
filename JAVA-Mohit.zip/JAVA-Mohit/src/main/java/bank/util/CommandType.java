package bank.util;
public enum CommandType { DEPOSIT, WITHDRAW, TRANSFER }
