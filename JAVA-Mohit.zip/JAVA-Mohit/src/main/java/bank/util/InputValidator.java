package bank.util;
import java.util.regex.Pattern;
public final class InputValidator {
    private InputValidator() {}
    private static final Pattern MOBILE=Pattern.compile("^[6-9][0-9]{9}$");
    private static final Pattern EMAIL=Pattern.compile("^[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PAN=Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
    private static final Pattern IFSC=Pattern.compile("^[A-Z]{4}0[A-Z0-9]{6}$");
    public static boolean isMobile(String text) { return text!=null && MOBILE.matcher(text).matches(); }
    public static boolean isEmail(String text) { return text!=null && EMAIL.matcher(text).matches(); }
    public static boolean isPan(String text) { return text!=null && PAN.matcher(text).matches(); }
    public static boolean isIfsc(String text) { return text!=null && IFSC.matcher(text).matches(); }
    public static boolean isPositiveAmount(String text) { return text!=null && text.matches("[1-9][0-9]*"); }
}
