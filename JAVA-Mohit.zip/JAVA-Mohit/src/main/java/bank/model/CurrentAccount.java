package bank.model;
public class CurrentAccount extends Account {
    private static final long serialVersionUID = 1L;
    private final long overdraftLimit;
    public CurrentAccount(String owner, long opening) { this(owner, opening, 10000); }
    public CurrentAccount(String owner, long opening, long limit) { super(owner, opening); overdraftLimit=limit; }
    @Override public double interestRate() { return 0.0; }
    @Override public boolean permitsWithdrawal(long amount) { return getBalance()-amount >= -overdraftLimit; }
}
