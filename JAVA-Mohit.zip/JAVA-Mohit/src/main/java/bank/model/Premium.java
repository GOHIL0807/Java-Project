package bank.model;
public interface Premium {}
