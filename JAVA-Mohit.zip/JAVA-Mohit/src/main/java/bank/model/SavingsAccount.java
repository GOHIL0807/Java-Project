package bank.model;
public class SavingsAccount extends Account implements Premium {
    private static final long serialVersionUID = 1L;
    private final long minimumBalance;
    public SavingsAccount(String owner, long opening) { this(owner, opening, 1000); }
    public SavingsAccount(String owner, long opening, long minimum) { super(owner, opening); minimumBalance=minimum; }
    @Override public double interestRate() { return 4.25; }
    @Override public boolean permitsWithdrawal(long amount) { return getBalance()-amount >= minimumBalance; }
    public long getMinimumBalance() { return minimumBalance; }
}
