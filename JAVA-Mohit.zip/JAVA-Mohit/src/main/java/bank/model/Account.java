package bank.model;

import bank.error.BankException;
import bank.error.InsufficientFundsException;
import bank.error.InvalidAmountException;
import bank.model.annotation.Id;
import bank.model.annotation.MaxLength;
import bank.model.annotation.Positive;
import java.io.Serializable;

public abstract class Account implements Transactable, InterestBearing, Serializable, Comparable<Account> {
    private static final long serialVersionUID = 1L;
    private static long nextNumber = 2501;

    @Id private final String accountNumber;
    @MaxLength(70) private final String ownerName;
    @Positive private long balance;
    private boolean open = true;

    protected Account(String ownerName, long openingBalance) {
        this(nextAccountNumber(), ownerName, openingBalance);
    }
    private static synchronized String nextAccountNumber() {
        return "MB" + nextNumber++;
    }
    public static synchronized void restoreSequence(String number) {
        try { nextNumber=Math.max(nextNumber,Long.parseLong(number.substring(2))+1); }
        catch (RuntimeException ignored) { /* Keep the sequence if an imported ID has another format. */ }
    }
    protected Account(String number, String ownerName, long openingBalance) {
        this.accountNumber = number;
        this.ownerName = ownerName;
        this.balance = openingBalance;
    }
    public abstract boolean permitsWithdrawal(long amount);

    @Override public synchronized void deposit(long amount) throws BankException {
        if (amount <= 0) throw new InvalidAmountException("Deposit must be positive.");
        try { balance = Math.addExact(balance, amount); }
        catch (ArithmeticException e) { throw new InvalidAmountException("Balance is too large."); }
    }
    @Override public synchronized boolean withdraw(long amount) throws BankException {
        if (amount <= 0) throw new InvalidAmountException("Withdrawal must be positive.");
        if (!permitsWithdrawal(amount)) {
            throw new InsufficientFundsException("The account's withdrawal rule was not met.", Math.max(0, amount - balance));
        }
        balance -= amount;
        return true;
    }
    public void transferTo(Account destination, long amount) throws BankException {
        if (destination == null) throw new InvalidAmountException("Choose a destination account.");
        Account first = compareTo(destination) <= 0 ? this : destination;
        Account second = first == this ? destination : this;
        synchronized (first) {
            synchronized (second) {
                boolean debited=false;
                try {
                    withdraw(amount);
                    debited=true;
                    destination.deposit(amount);
                } catch (BankException e) {
                    if (debited) {
                        try { deposit(amount); }
                        catch (BankException rollbackError) { e.addSuppressed(rollbackError); }
                    }
                    throw e;
                }
            }
        }
    }
    public synchronized long getBalance() { return balance; }
    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName() { return ownerName; }
    public boolean isOpen() { return open; }
    public void close() { open = false; }
    @Override public int compareTo(Account other) { return accountNumber.compareTo(other.accountNumber); }
    @Override public boolean equals(Object other) { return other instanceof Account a && accountNumber.equals(a.accountNumber); }
    @Override public int hashCode() { return accountNumber.hashCode(); }
    @Override public String toString() { return accountNumber + " | " + ownerName + " | ₹" + getBalance(); }
}
