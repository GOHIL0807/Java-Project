package bank.model;
public interface InterestBearing {
    double interestRate();
    default double yearlyInterest(Account account) {
        return account.getBalance() * interestRate() / 100.0;
    }
}
