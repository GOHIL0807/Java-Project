package bank.model;
public class TermDepositAccount extends Account {
    private static final long serialVersionUID = 1L;
    public TermDepositAccount(String owner, long opening) { super(owner, opening); }
    @Override public double interestRate() { return 6.5; }
    @Override public boolean permitsWithdrawal(long amount) { return false; }
}
