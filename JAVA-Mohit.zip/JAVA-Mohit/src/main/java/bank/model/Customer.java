package bank.model;

import bank.model.annotation.Id;
import bank.model.annotation.MaxLength;
import java.io.Serializable;

public class Customer implements Serializable, Cloneable {
    private static final long serialVersionUID = 1L;
    private static long nextId = 201;

    @Id private final String customerId;
    @MaxLength(70) private final String name;
    private final String email;
    private final String mobile;
    private final Address address;

    public Customer(String name, String email, String mobile, Address address) {
        this.customerId = "CU" + nextId++;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
    }
    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public Address getAddress() { return address; }
    @Override public Customer clone() {
        try { return (Customer) super.clone(); }
        catch (CloneNotSupportedException e) { throw new AssertionError(e); }
    }

    public static class Address implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String line, city, postalCode;
        public Address(String line, String city, String postalCode) {
            this.line=line; this.city=city; this.postalCode=postalCode;
        }
        public String getLine() { return line; }
        public String getCity() { return city; }
        public String getPostalCode() { return postalCode; }
    }
}
