package bank.service;

import bank.error.AccountNotFoundException;
import bank.error.BankException;
import bank.error.InvalidAmountException;
import bank.model.*;
import bank.util.Command;
import bank.util.CommandType;
import bank.util.InputValidator;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BankService {
    private final Repository<Account> accounts=new Repository<>();
    private final Path folder=Path.of("data");
    private final Path accountFile=folder.resolve("bank-state.dat");
    private final Path journal=folder.resolve("transactions/ledger.log");

    public BankService() {
        try { for (Account account:AccountFiles.load(accountFile)) { Account.restoreSequence(account.getAccountNumber()); accounts.save(account); } }
        catch (IOException | ClassNotFoundException e) { System.err.println("Starting with empty account data: "+e.getMessage()); }
    }
    public Account openAccount(String owner,long opening,String type) throws BankException {
        if (owner==null || owner.isBlank() || owner.length()>70) throw new InvalidAmountException("Enter an owner name up to 70 characters.");
        if (opening<0) throw new InvalidAmountException("Opening balance cannot be negative.");
        Account account=switch(type.toUpperCase()) {
            case "CURRENT" -> new CurrentAccount(owner,opening);
            case "TERM" -> new TermDepositAccount(owner,opening);
            case "SAVINGS" -> new SavingsAccount(owner,opening);
            default -> throw new InvalidAmountException("Account type must be SAVINGS, CURRENT or TERM.");
        };
        accounts.save(account);
        return account;
    }
    private Account require(String number) throws AccountNotFoundException {
        Account a=accounts.findById(number);
        if (a==null || !a.isOpen()) throw new AccountNotFoundException(number);
        return a;
    }
    public void deposit(String number,long amount) throws BankException {
        Account a=require(number); a.deposit(amount); log("DEPOSIT",number,null,amount);
    }
    public void withdraw(String number,long amount) throws BankException {
        Account a=require(number);
        if (!InputValidator.isPositiveAmount(Long.toString(amount))) throw new InvalidAmountException("Enter a positive amount.");
        WithdrawRule rule=(account,value)->account.permitsWithdrawal(value);
        if (!rule.allow(a,amount)) a.withdraw(amount); // Let Account provide its specific exception.
        a.withdraw(amount); log("WITHDRAW",number,null,amount);
    }
    public void transfer(String from,String to,long amount) throws BankException {
        Account source=require(from), destination=require(to);
        source.transferTo(destination,amount);
        log("TRANSFER",from,to,amount);
    }
    public String statement(String number) throws BankException {
        Account a=require(number);
        return "ACCOUNT SUMMARY\nNumber: "+a.getAccountNumber()+"\nOwner: "+a.getOwnerName()+"\nType: "+a.getClass().getSimpleName()+"\nBalance: ₹"+a.getBalance()+"\nInterest: "+a.interestRate()+"%";
    }
    public List<Account> list() {
        ArrayList<Account> result=accounts.findAll();
        result.sort(Comparator.comparingLong(Account::getBalance).reversed());
        return result;
    }
    public void apply(Command command) throws BankException {
        if (command.type()==CommandType.DEPOSIT) deposit(command.source(),command.amount());
        else if (command.type()==CommandType.WITHDRAW) withdraw(command.source(),command.amount());
        else transfer(command.source(),command.destination(),command.amount());
    }
    public synchronized void save() throws IOException { AccountFiles.save(accounts.findAll().toArray(Account[]::new),accountFile); }
    public String report() throws IOException { return DailyReport.write(journal.getParent(),folder.resolve("daily-report.txt")); }
    private void log(String action,String source,String destination,long amount) throws BankException {
        String row=action+" "+source+(destination==null?"":" "+destination)+" "+amount;
        try { TransactionJournal.add(journal,row); }
        catch (IOException e) { throw new BankException("The balance changed, but the ledger could not be written: "+e.getMessage()); }
    }
}
