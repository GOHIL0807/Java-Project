package bank.service;

import bank.error.BankException;
import bank.util.Command;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class BatchProcessor {
    private final BankService bank;
    public BatchProcessor(BankService bank) { this.bank=bank; }

    public List<String> process(List<Command> commands) {
        if(commands.isEmpty()) return List.of();
        TransactionBuffer buffer=new TransactionBuffer();
        commands.forEach(buffer::add);
        buffer.finish();
        int count=Math.min(4,commands.size());
        ExecutorService pool=Executors.newFixedThreadPool(count);
        ConcurrentLinkedQueue<String> results=new ConcurrentLinkedQueue<>();
        List<Future<?>> workers=new ArrayList<>();
        for(int i=0;i<count;i++) workers.add(pool.submit(()->{
            try {
                Command command;
                while((command=buffer.next())!=null) {
                    try { bank.apply(command); results.add("OK  "+command); }
                    catch(BankException|RuntimeException e) { results.add("ERR "+command+" - "+e.getMessage()); }
                }
            } catch(InterruptedException e) { Thread.currentThread().interrupt(); }
        }));
        pool.shutdown();
        try { for(Future<?> worker:workers) worker.get(); }
        catch(InterruptedException e) { Thread.currentThread().interrupt(); results.add("Batch interrupted."); }
        catch(ExecutionException e) { results.add("Batch worker failed: "+e.getCause()); }
        return new ArrayList<>(results);
    }
}
