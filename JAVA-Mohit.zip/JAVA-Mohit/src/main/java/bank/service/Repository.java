package bank.service;

import bank.model.annotation.Id;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;

public class Repository<T> {
    private final HashMap<String,T> items = new HashMap<>();
    public synchronized T save(T item) {
        try {
            for (Class<?> type=item.getClass(); type!=null && type!=Object.class; type=type.getSuperclass()) {
                for (Field field:type.getDeclaredFields()) {
                    if (field.isAnnotationPresent(Id.class)) {
                        field.setAccessible(true);
                        items.put(field.get(item).toString(),item);
                        return item;
                    }
                }
            }
            throw new IllegalArgumentException("This class has no @Id field.");
        } catch (IllegalAccessException e) { throw new IllegalArgumentException("Could not read @Id.",e); }
    }
    @SafeVarargs public final synchronized void saveAll(T... values) { for (T value:values) save(value); }
    public synchronized T findById(String id) { return items.get(id); }
    public synchronized ArrayList<T> findAll() { return new ArrayList<>(items.values()); }
    public synchronized boolean delete(String id) { return items.remove(id)!=null; }
    public synchronized int size() { return items.size(); }
}
