package bank.service;

import java.io.IOException;
import java.nio.file.*;

public final class TransactionJournal {
    private TransactionJournal() {}
    public static void add(Path file, String line) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        Files.writeString(file,line+System.lineSeparator(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
    }
}
