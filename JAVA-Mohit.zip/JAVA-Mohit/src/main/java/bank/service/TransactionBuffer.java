package bank.service;

import bank.util.Command;
import java.util.ArrayDeque;
import java.util.Queue;

/** A small producer-consumer queue using wait and notifyAll. */
public class TransactionBuffer {
    private final Queue<Command> commands=new ArrayDeque<>();
    private boolean finished;
    public synchronized void add(Command command) { commands.add(command); notifyAll(); }
    public synchronized void finish() { finished=true; notifyAll(); }
    public synchronized Command next() throws InterruptedException {
        while(commands.isEmpty()&&!finished) wait();
        return commands.isEmpty()?null:commands.remove();
    }
}
