package bank.service;
import bank.model.Account;
public class AccountWorker implements Runnable {
    private final Account account; private final int deposits; private final long amount;
    public AccountWorker(Account account,int deposits,long amount) { this.account=account;this.deposits=deposits;this.amount=amount; }
    @Override public void run() {
        for(int i=0;i<deposits;i++) try { account.deposit(amount); }
        catch(Exception e) { throw new IllegalStateException(e); }
    }
}
