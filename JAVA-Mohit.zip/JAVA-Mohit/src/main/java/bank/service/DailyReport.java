package bank.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public final class DailyReport {
    private DailyReport() {}
    public static String write(Path logFolder,Path reportFile) throws IOException {
        long deposits=0, withdrawals=0, transfers=0;
        StringBuilder details=new StringBuilder("MINIBANK DAILY REPORT\n");
        if(Files.isDirectory(logFolder)) try(DirectoryStream<Path> files=Files.newDirectoryStream(logFolder,"*.log")) {
            for(Path file:files) {
                BasicFileAttributes attr=Files.readAttributes(file,BasicFileAttributes.class);
                details.append(file.getFileName()).append("  ").append(attr.size()).append(" bytes  ").append(attr.lastModifiedTime()).append('\n');
                try(BufferedReader reader=Files.newBufferedReader(file)) {
                    String line;
                    while((line=reader.readLine())!=null) {
                        String[] part=line.trim().split("\\s+");
                        try {
                            if(part[0].equals("DEPOSIT")) deposits+=Long.parseLong(part[2]);
                            else if(part[0].equals("WITHDRAW")) withdrawals+=Long.parseLong(part[2]);
                            else if(part[0].equals("TRANSFER")) transfers+=Long.parseLong(part[3]);
                        } catch(RuntimeException ignored) { /* Ignore malformed log rows. */ }
                    }
                }
            }
        }
        details.append("\nDeposits: ₹").append(deposits).append("\nWithdrawals: ₹").append(withdrawals)
            .append("\nTransfers: ₹").append(transfers).append("\nNet deposits: ₹").append(deposits-withdrawals).append('\n');
        Files.createDirectories(reportFile.toAbsolutePath().getParent());
        Files.writeString(reportFile,details.toString());
        return details.toString();
    }
}
