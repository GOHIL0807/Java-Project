package bank.error;
public class AccountNotFoundException extends BankException {
    private static final long serialVersionUID = 1L;
    public AccountNotFoundException(String number) { super("No open account found for " + number); }
}
