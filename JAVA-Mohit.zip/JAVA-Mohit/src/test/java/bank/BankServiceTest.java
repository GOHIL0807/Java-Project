package bank;

import bank.error.InsufficientFundsException;
import bank.model.SavingsAccount;
import bank.service.AccountWorker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BankServiceTest {
    @Test void aDepositAddsToBalance() throws Exception {
        SavingsAccount account=new SavingsAccount("Test",2000,0);
        account.deposit(350);
        assertEquals(2350,account.getBalance());
    }
    @Test void tooLargeAWithdrawalIsRejected() {
        SavingsAccount account=new SavingsAccount("Test",2000,0);
        assertThrows(InsufficientFundsException.class,()->account.withdraw(3000));
        assertEquals(2000,account.getBalance());
    }
    @Test void synchronizedDepositsKeepTheExpectedTotal() throws InterruptedException {
        SavingsAccount account=new SavingsAccount("Test",0,0);
        Thread[] workers=new Thread[8];
        for(int i=0;i<workers.length;i++) workers[i]=new Thread(new AccountWorker(account,500,2));
        for(Thread worker:workers)worker.start();
        for(Thread worker:workers)worker.join();
        assertEquals(8000,account.getBalance());
    }
}
