$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$classes = Join-Path $root "build\classes"
if (Test-Path $classes) { Remove-Item -Recurse -Force $classes }
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$files = Get-ChildItem (Join-Path $root "src\main\java") -Filter *.java -Recurse | ForEach-Object FullName
javac --release 17 -encoding UTF-8 -d $classes $files
if ($LASTEXITCODE -ne 0) { throw "Compilation failed" }
jar --create --file (Join-Path $root "minibank.jar") --main-class bank.Main -C $classes .
if ($LASTEXITCODE -ne 0) { throw "JAR creation failed" }
Write-Host "Created minibank.jar"
